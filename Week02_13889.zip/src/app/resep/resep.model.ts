export interface Resep{
    id:string;
    title:string;
    imageUrl:string;
    ingredients:string[];
}